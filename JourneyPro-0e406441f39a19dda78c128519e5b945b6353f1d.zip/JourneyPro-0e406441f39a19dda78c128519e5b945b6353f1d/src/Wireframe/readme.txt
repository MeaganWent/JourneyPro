This file contains all images that are featured on the wire diagram on our wiki. 
