[Lean Canvas](https://docs.google.com/presentation/d/1jRijWwW_jJ0aea4JcwAcbI7aeZ3mLCRL7WlYylwQMuc/edit?usp=sharing)

- Free tier with Ads

- Paid tier with no ads and additional features
  - Includes data from APIs we need to pay for

Sponsorships? Need to research viability
