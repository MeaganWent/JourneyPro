[US1: User Account Creation](https://docs.google.com/presentation/d/1g5zT2REaCrqEDMP4EulbblFtIUeWTSHqBgf67PozY_U/edit?usp=sharing)

[US2: User Login](https://docs.google.com/presentation/d/1gz8mqAA0b2mBx5OiXAEj5tHtlTUl7_r9ycJhn0rXkAU/edit?usp=sharing)

[US3: Backend Management](https://docs.google.com/presentation/d/18Xp1fqXHYjtXBSi6bDzB-GKD2dkXhW9WS6PHmj6saaY/edit?usp=sharing)

[US4: Golden Path: Login > Trip Make/Delete > Logout](https://docs.google.com/presentation/d/1pnrMZ2o84YGXA7Mssq111Nm7eI0hOhE2WvypIOHl6uA/edit?usp=sharing)

[US5: Other](https://docs.google.com/presentation/d/1DtV7uAlCS0vpKvauy5S1hbWTroAA0Ip4jFSDuWou954/edit?usp=sharing)
